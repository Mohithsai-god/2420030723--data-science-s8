import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression

print("----Linear Regression----")
X_linear = np.array([[1000], [1200], [1500], [1800], [2000]])

y_linear = np.array([50, 55, 65, 80, 90])

linear_model = LinearRegression()


linear_model.fit(X_linear, y_linear)

new_house_size = np.array([[1700]])
predicted_price = linear_model.predict(new_house_size)

print("Predicted House Price:", predicted_price)
print("R2 Score:", linear_model.score(X_linear, y_linear))