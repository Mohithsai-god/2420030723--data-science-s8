let searchTimer;

function searchMovies() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
        const query = document.getElementById("searchBox").value.trim();

        fetch("/search?query=" + encodeURIComponent(query))
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById("movieContainer");
                const count = document.getElementById("resultCount");

                if (count) {
                    count.textContent = `${data.length} movies`;
                }

                if (!data.length) {
                    container.innerHTML = `
                        <div class="empty">
                            <div>🔎</div>
                            <h2>No movies found</h2>
                            <p>Try another movie title or genre.</p>
                        </div>`;
                    return;
                }

                container.innerHTML = data.map(movie => `
                    <article class="movie-card">
                        <div class="poster">
                            <img src="/static/images/${movie.image}" alt="${escapeHtml(movie.title)}"
                                 onerror="this.style.display='none'; this.parentElement.classList.add('fallback');">
                            <span class="poster-fallback">🎬</span>
                            <span class="rating">⭐ ${movie.rating}</span>
                        </div>
                        <div class="card-body">
                            <h3>${escapeHtml(movie.title)}</h3>
                            <p class="meta">${movie.year} • ${escapeHtml(movie.genre.replaceAll("|", " • "))}</p>
                            <p class="description">${escapeHtml(movie.description)}</p>
                            <a class="details-btn" href="/movie/${movie.id}">View Details →</a>
                        </div>
                    </article>
                `).join("");
            });
    }, 180);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function toggleFavorite(movieId) {
    fetch(`/favorite/${movieId}`, { method: "POST" })
        .then(async response => {
            const data = await response.json();
            if (response.status === 401) {
                window.location.href = "/login";
                return;
            }
            alert(data.action === "added"
                ? "Movie added to favorites ❤️"
                : "Movie removed from favorites.");
        });
}
