import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

movies = pd.read_csv("movies.csv")

movies["description"] = movies["description"].fillna("")
movies["genre"] = movies["genre"].fillna("")
movies["features"] = movies["genre"] + " " + movies["description"]

vectorizer = TfidfVectorizer(stop_words="english")
feature_matrix = vectorizer.fit_transform(movies["features"])
similarity = cosine_similarity(feature_matrix)

def recommend_movies(movie_id, count=6):
    matches = movies.index[movies["id"] == movie_id].tolist()
    if not matches:
        return []

    index = matches[0]
    scores = list(enumerate(similarity[index]))
    scores.sort(key=lambda x: x[1], reverse=True)

    recommendations = []
    for i, score in scores[1:count + 1]:
        movie = movies.iloc[i].to_dict()
        movie["similarity"] = round(float(score) * 100, 1)
        recommendations.append(movie)

    return recommendations
