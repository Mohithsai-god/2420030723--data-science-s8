from flask import Flask, render_template, request, jsonify, redirect, session
import sqlite3
import pandas as pd
from recommendation import recommend_movies
from database import init_db, get_db

app = Flask(__name__)
app.secret_key = "movie-recommendation-demo-key"

MOVIES_FILE = "movies.csv"
movies = pd.read_csv(MOVIES_FILE)

init_db()

@app.route("/")
def home():
    movie_list = movies.to_dict(orient="records")
    return render_template("index.html", movies=movie_list, user=session.get("user"))

@app.route("/movie/<int:movie_id>")
def movie_details(movie_id):
    row = movies[movies["id"] == movie_id]
    if row.empty:
        return "Movie not found", 404
    movie = row.iloc[0].to_dict()
    recommendations = recommend_movies(movie_id, 6)
    return render_template("details.html", movie=movie,
                           recommendations=recommendations,
                           user=session.get("user"))

@app.route("/search")
def search():
    query = request.args.get("query", "").strip()
    if not query:
        result = movies
    else:
        mask = (
            movies["title"].str.contains(query, case=False, na=False) |
            movies["genre"].str.contains(query, case=False, na=False)
        )
        result = movies[mask]
    return jsonify(result.to_dict(orient="records"))

@app.route("/recommend/<int:movie_id>")
def recommend(movie_id):
    return jsonify(recommend_movies(movie_id, 6))

@app.route("/api/movies")
def api_movies():
    return jsonify(movies.to_dict(orient="records"))

@app.route("/register", methods=["GET", "POST"])
def register():
    message = ""
    if request.method == "POST":
        username = request.form["username"].strip()
        email = request.form["email"].strip()
        password = request.form["password"]

        db = get_db()
        try:
            db.execute("INSERT INTO users(username,email,password) VALUES(?,?,?)",
                       (username, email, password))
            db.commit()
            db.close()
            return redirect("/login")
        except sqlite3.IntegrityError:
            message = "Username or email already exists."
            db.close()

    return render_template("register.html", message=message)

@app.route("/login", methods=["GET", "POST"])
def login():
    message = ""
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"]

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE email=? AND password=?",
            (email, password)
        ).fetchone()
        db.close()

        if user:
            session["user"] = {"id": user["id"], "username": user["username"], "email": user["email"]}
            return redirect("/")
        message = "Invalid email or password."

    return render_template("login.html", message=message)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/favorites")
def favorites():
    if "user" not in session:
        return redirect("/login")

    db = get_db()
    rows = db.execute(
        "SELECT movie_id FROM favorites WHERE user_id=?",
        (session["user"]["id"],)
    ).fetchall()
    db.close()

    ids = {row["movie_id"] for row in rows}
    favorite_movies = movies[movies["id"].isin(ids)].to_dict(orient="records")
    return render_template("favorites.html", movies=favorite_movies,
                           user=session["user"])

@app.route("/favorite/<int:movie_id>", methods=["POST"])
def favorite(movie_id):
    if "user" not in session:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    existing = db.execute(
        "SELECT id FROM favorites WHERE user_id=? AND movie_id=?",
        (session["user"]["id"], movie_id)
    ).fetchone()

    if existing:
        db.execute("DELETE FROM favorites WHERE user_id=? AND movie_id=?",
                   (session["user"]["id"], movie_id))
        action = "removed"
    else:
        db.execute("INSERT INTO favorites(user_id,movie_id) VALUES(?,?)",
                   (session["user"]["id"], movie_id))
        action = "added"

    db.commit()
    db.close()
    return jsonify({"success": True, "action": action})

@app.route("/admin")
def admin():
    if "user" not in session:
        return redirect("/login")
    db = get_db()
    users = db.execute("SELECT id,username,email FROM users ORDER BY id DESC").fetchall()
    db.close()
    return render_template("admin.html", users=users, movies=movies.to_dict(orient="records"),
                           user=session["user"])

if __name__ == "__main__":
    app.run(debug=True)
