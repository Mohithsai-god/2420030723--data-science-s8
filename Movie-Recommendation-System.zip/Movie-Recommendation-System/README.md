# Movie Recommendation System

A full-stack Movie Recommendation System built with Flask, SQLite, Pandas and scikit-learn.

## Features

- Movie search
- Movie details and descriptions
- AI-style similar movie recommendations
- TF-IDF + cosine similarity
- User registration and login
- Favorite movies
- REST API endpoints
- Responsive frontend
- SQLite database
- Admin overview page

## Run

Open PowerShell in this folder:

```powershell
pip install -r requirements.txt
python app.py
```

Then open:

http://127.0.0.1:5000

## API

- GET `/api/movies`
- GET `/search?query=iron`
- GET `/recommend/1`

## Notes

The included poster files are generated placeholder images. Replace them with real movie posters if desired.
